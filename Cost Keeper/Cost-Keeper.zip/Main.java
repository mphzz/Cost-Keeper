class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    SpendingTracker st = new SpendingTracker();
    st.setVisible(true);
    /*
    ***********************************************************
    *      YOU MUST USE THIS IN CONSOLE:                      *
    *                                                         *
    * java -classpath .:target/dependency/* SpendingTracker   *
    *                                                         *
    *      TO RUN THIS PROGRAM ON REPL.IT                     *
    ***********************************************************
    */
  }
}